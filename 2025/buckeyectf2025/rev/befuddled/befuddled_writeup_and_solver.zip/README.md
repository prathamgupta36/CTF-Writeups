# BuckeyeCTF 2025 – rev/befuddled

This repo contains tooling and a writeup for the “befuddled” reversing challenge.

- Final flag: `bctf{c0mPIle_Th3_unC0mp1labl3}`
- Full writeup: see `WRITEUP.md` for approach and details.

## Quick Start
- Verify using the provided binary:
  - `./befuddled <<< 'bctf{c0mPIle_Th3_unC0mp1labl3}'`
- Solve (greedy, right-to-left):
  - `python3 solver.py --mode greedy --max-steps 80`

## Solver CLI
- Greedy (default):
  - `python3 solver.py --mode greedy --max-steps 80 --verbose`
  - Options: `--alphabet printable|alnum|alpha|lower|upper|hex|word|<literal>`, `--save progress.json`, `--save-every N`, `--start SUFFIX`
- DFS (prototype):
  - `python3 solver.py --mode dfs --max-steps 24`
- Beam search:
  - `python3 solver.py --mode beam --depth 60 --beam 2000 --branch 8`
- Verify a candidate:
  - `python3 solver.py --mode verify --candidate c0mPIle_Th3_unC0mp1labl3`
- Inspect gate events for a suffix (inside braces):
  - `python3 solver.py --mode events --candidate A_unC0mp1labl3 --events-limit 10`

## Program Source Selection
- Use the embedded grid from the ELF (default):
  - `--binary befuddled --offset 0x8038 --width 0x52 --height 25`
- Or load a text grid:
  - `--program-file program.bf`

Refer to `WRITEUP.md` for how the greedy longest‑path heuristic reconstructs the flag.
