import os
import http.client
import urllib.parse

from flask import Flask, Response, request
from http.cookies import SimpleCookie

app = Flask(__name__)

BACKEND_URL = os.environ.get("BACKEND_URL", "http://app:3000")

MAX_COOKIES = 16


def parse_cookie_header(raw: str) -> dict[str, str]:
    sc = SimpleCookie()
    try:
        sc.load(raw)
    except Exception:
        return {}
    return {key: morsel.value for key, morsel in sc.items()}


def check_cookies(cookie_header: str) -> str | None:
    cookie_header = cookie_header.strip()
    if not cookie_header:
        return None

    cookies = parse_cookie_header(cookie_header)
    if not cookies:
        return "malformed cookie"

    if len(cookies) > MAX_COOKIES:
        return "too many cookies"

    for name in cookies:
        if "admin" in name.lower():
            return "blocked cookie"

    return None


@app.route("/", defaults={"path": ""}, methods=["GET", "POST", "PUT", "DELETE"])
@app.route("/<path:path>", methods=["GET", "POST", "PUT", "DELETE"])
def gateway(path):
    violation = check_cookies(request.headers.get("Cookie", ""))
    if violation:
        return Response("Access denied.\n", status=403, content_type="text/plain")

    parsed = urllib.parse.urlparse(BACKEND_URL)
    target_path = f"/{path}"
    qs = request.query_string.decode()
    if qs:
        target_path += f"?{qs}"

    conn = http.client.HTTPConnection(parsed.hostname, parsed.port or 80)
    fwd_headers = {}
    for key, value in request.headers:
        if key.lower() in ("host", "transfer-encoding"):
            continue
        fwd_headers[key] = value

    conn.request(request.method, target_path, body=request.get_data() or None, headers=fwd_headers)
    resp = conn.getresponse()

    resp_body = resp.read()
    resp_status = resp.status

    hop_by_hop = {
        "transfer-encoding", "content-length", "connection",
        "keep-alive", "upgrade", "proxy-authenticate",
        "proxy-authorization", "te", "trailers",
    }
    headers = []
    for key, value in resp.getheaders():
        if key.lower() not in hop_by_hop:
            headers.append((key, value))

    conn.close()
    return Response(resp_body, status=resp_status, headers=headers)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
