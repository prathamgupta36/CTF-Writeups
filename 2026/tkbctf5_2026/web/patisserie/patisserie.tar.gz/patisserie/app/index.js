const express = require("express");
const cookieParser = require("cookie-parser");

const COOKIE_SECRET = process.env.COOKIE_SECRET || "secret";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "admin";
const FLAG = process.env.FLAG || "tkbctf{dummy}";

const app = express();
app.use(cookieParser(COOKIE_SECRET));
app.use(express.urlencoded({ extended: false }));

const esc = (s) =>
  String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");

const PAGE_STYLE = `
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: "Segoe UI", system-ui, -apple-system, sans-serif;
      background: #faf5ee; color: #3b2f1e; line-height: 1.6;
    }
    .container { max-width: 680px; margin: 0 auto; padding: 2rem 1.5rem; }
    h1 { color: #6b3e26; font-size: 1.75rem; margin-bottom: .75rem; }
    h2 { color: #8b5e3c; font-size: 1.25rem; margin-bottom: .5rem; }
    p { margin-bottom: .5rem; }
    a { color: #a0522d; text-decoration: none; }
    a:hover { text-decoration: underline; }
    .card {
      background: #fff; border-radius: 10px; padding: 1.25rem 1.5rem;
      box-shadow: 0 1px 4px rgba(0,0,0,.06); margin-bottom: 1.25rem;
    }
    input[type=text], input[type=password] {
      padding: .45rem .7rem; border: 1px solid #d0c4b4; border-radius: 6px;
      font-size: .95rem; background: #fefcf9; outline: none;
      transition: border-color .15s;
    }
    input:focus { border-color: #a0522d; }
    button, .btn {
      display: inline-block; padding: .45rem 1.1rem;
      background: #a0522d; color: #fff; border: none; border-radius: 6px;
      font-size: .95rem; cursor: pointer; text-decoration: none;
      transition: background .15s;
    }
    button:hover, .btn:hover { background: #8b4513; }
    .btn-sm { padding: .3rem .8rem; font-size: .85rem; }
    .btn-outline {
      background: transparent; color: #a0522d; border: 1px solid #a0522d;
    }
    .btn-outline:hover { background: #a0522d; color: #fff; }
    .notice {
      padding: 1rem 1.25rem; border-radius: 8px; margin-bottom: 1.25rem;
      font-size: .95rem; display: flex; align-items: flex-start; gap: .6rem;
    }
    .notice-warn { background: #fef7e6; border: 1px solid #e8d5a3; color: #7a5c1f; }
    .notice-error { background: #fdf0f0; border: 1px solid #e8b4b4; color: #8b2020; }
    .notice-icon { font-size: 1.1rem; flex-shrink: 0; margin-top: .1rem; }
    .recipe-list { list-style: none; }
    .recipe-list li {
      padding: .65rem 0; border-bottom: 1px solid #f0ebe3;
    }
    .recipe-list li:last-child { border-bottom: none; }
    .recipe-list a { font-weight: 500; }
    .recipe-desc { color: #7a6b5a; font-size: .9rem; }
    nav {
      background: #5c3d2e; padding: 0 1.5rem;
      display: flex; align-items: center; height: 3rem;
    }
    nav a {
      color: #f5ebe0; text-decoration: none; margin-right: 1.25rem;
      font-weight: 600; font-size: .95rem;
    }
    nav a:hover { color: #fff; text-decoration: none; }
    .nav-brand { font-size: 1.05rem; margin-right: 2rem; }
    .nav-right { margin-left: auto; display: flex; align-items: center; gap: .75rem; }
    .nav-right span { color: #ddd3c7; font-size: .9rem; font-weight: 400; }
    .nav-right a { margin-right: 0; font-weight: 400; font-size: .9rem; color: #e8d5c0; }
    .back-link { display: inline-block; margin-top: 1rem; font-size: .9rem; }
    form { display: flex; gap: .5rem; align-items: center; flex-wrap: wrap; }
  </style>
`;

const nav = (user) => `
  <nav>
    <a class="nav-brand" href="/">Patisserie</a>
    <a href="/recipes">Recipes</a>
    <a href="/search">Search</a>
    <a href="/admin">Admin</a>
    <div class="nav-right">
      ${
        user
          ? `<span>Hi, ${esc(user)}</span><a href="/logout">Logout</a>`
          : `<a href="/">Login</a>`
      }
    </div>
  </nav>
`;

const RECIPES = [
  {
    id: 1,
    name: "Tarte Tatin",
    desc: "Upside-down caramelised apple tart with buttery puff pastry.",
    tag: "tart",
  },
  {
    id: 2,
    name: "Mille-feuille",
    desc: "Crispy layered pastry filled with vanilla cream and topped with fondant.",
    tag: "classic",
  },
  {
    id: 3,
    name: "Paris-Brest",
    desc: "Choux ring filled with praline mousseline cream.",
    tag: "choux",
  },
  {
    id: 4,
    name: "Canelé de Bordeaux",
    desc: "Small caramelised cakes with a custardy rum-vanilla centre.",
    tag: "cake",
  },
  {
    id: 5,
    name: "Opéra",
    desc: "Layered almond sponge, coffee buttercream and chocolate ganache.",
    tag: "chocolate",
  },
];

const buildFilter = (query) => {
  const q = String(query).toLowerCase().replace(/[^a-z0-9 ]/g, "");
  return new Function(
    "r",
    `return r.name.toLowerCase().includes("${q}") || r.tag.toLowerCase().includes("${q}")`
  );
};

app.get("/", (req, res) => {
  const user = req.signedCookies.user;
  if (user) {
    return res.redirect("/recipes");
  }
  res.send(`<!DOCTYPE html><html><head><meta charset="utf-8"><title>Patisserie</title>${PAGE_STYLE}</head>
<body>
${nav()}
<div class="container">
  <h1>Welcome to Patisserie!</h1>
  <p>Sign in to browse our finest pastry recipes.</p>
  <div class="card">
    <form action="/login" method="POST">
      <input type="text" name="username" placeholder="Your name" required>
      <button type="submit">Sign In</button>
    </form>
  </div>
</div>
</body></html>`);
});

app.post("/login", (req, res) => {
  const username = (req.body.username || "").trim().slice(0, 32);
  if (!username) return res.redirect("/");
  res.cookie("user", username, { httpOnly: true, signed: true });
  res.redirect("/recipes");
});

app.get("/logout", (req, res) => {
  res.clearCookie("user", { signed: true });
  res.redirect("/");
});

app.get("/recipes", (req, res) => {
  const user = req.signedCookies.user;
  const list = RECIPES.map(
    (r) =>
      `<li><a href="/recipe/${r.id}">${esc(r.name)}</a> <span class="recipe-desc">\u2014 ${esc(r.desc)}</span></li>`
  ).join("\n");
  res.send(`<!DOCTYPE html><html><head><meta charset="utf-8"><title>Recipes - Patisserie</title>${PAGE_STYLE}</head>
<body>
${nav(user)}
<div class="container">
  <h1>Pastry Recipes</h1>
  <div class="card">
    <ul class="recipe-list">${list}</ul>
  </div>
</div>
</body></html>`);
});

app.get("/recipe/:id", (req, res) => {
  const user = req.signedCookies.user;
  const recipe = RECIPES.find((r) => r.id === Number(req.params.id));
  if (!recipe) return res.status(404).send("Recipe not found");
  res.send(`<!DOCTYPE html><html><head><meta charset="utf-8"><title>${esc(recipe.name)} - Patisserie</title>${PAGE_STYLE}</head>
<body>
${nav(user)}
<div class="container">
  <h1>${esc(recipe.name)}</h1>
  <div class="card">
    <p>${esc(recipe.desc)}</p>
    <p style="color:#7a6b5a;font-style:italic;margin-top:.75rem">Full recipe available to registered pâtissiers.</p>
  </div>
  <a class="back-link" href="/recipes">&larr; Back to recipes</a>
</div>
</body></html>`);
});

app.get("/search", (req, res) => {
  const user = req.signedCookies.user;
  const q = req.query.q || "";
  let results = [];
  if (q) {
    try {
      const filter = buildFilter(q);
      results = RECIPES.filter(filter);
    } catch {
      results = [];
    }
  }
  const list = results.length
    ? results
        .map(
          (r) =>
            `<li><a href="/recipe/${r.id}">${esc(r.name)}</a> <span class="recipe-desc">\u2014 ${esc(r.desc)}</span></li>`
        )
        .join("\n")
    : q
      ? "<li>No recipes found.</li>"
      : "";
  res.send(`<!DOCTYPE html><html><head><meta charset="utf-8"><title>Search - Patisserie</title>${PAGE_STYLE}</head>
<body>
${nav(user)}
<div class="container">
  <h1>Search Recipes</h1>
  <div class="card">
    <form action="/search" method="GET">
      <input type="text" name="q" placeholder="Search..." value="${esc(q)}">
      <button type="submit">Search</button>
    </form>
  </div>
  ${list ? `<div class="card"><ul class="recipe-list">${list}</ul></div>` : ""}
</div>
</body></html>`);
});

app.get("/admin", (req, res) => {
  if (req.cookies.is_admin === "1") {
    return res.send(`<!DOCTYPE html><html><head><meta charset="utf-8"><title>Admin - Patisserie</title>${PAGE_STYLE}</head>
<body>
${nav("Admin")}
<div class="container">
  <h1>Admin Panel</h1>
  <div class="card">
    <h2>Secret Recipe</h2>
    <p>${FLAG}</p>
  </div>
</div>
</body></html>`);
  }
  const failed = req.query.error === "1";
  res.status(403).send(`<!DOCTYPE html><html><head><meta charset="utf-8"><title>Forbidden - Patisserie</title>${PAGE_STYLE}</head>
<body>
${nav(req.signedCookies.user)}
<div class="container">
  <h1>Admin Panel</h1>
  <div class="notice notice-warn">
    <span class="notice-icon">&#x1f512;</span>
    <div>You do not have permission to view this page. Please authenticate below.</div>
  </div>
  ${failed ? `<div class="notice notice-error"><span class="notice-icon">&#x2716;</span><div>Invalid password. Please try again.</div></div>` : ""}
  <div class="card">
    <h2>Admin Login</h2>
    <form action="/admin" method="POST">
      <input type="password" name="password" placeholder="Admin password" required>
      <button type="submit">Login</button>
    </form>
  </div>
  <a class="back-link" href="/recipes">&larr; Back to recipes</a>
</div>
</body></html>`);
});

app.post("/admin", (req, res) => {
  const input = req.body.password || "";
  if (input === ADMIN_PASSWORD) {
    res.cookie("is_admin", "1", { httpOnly: true });
    return res.redirect("/admin");
  }
  res.redirect("/admin?error=1");
});

app.listen(3000, () => {
  console.log("Patisserie app listening on port 3000");
});
