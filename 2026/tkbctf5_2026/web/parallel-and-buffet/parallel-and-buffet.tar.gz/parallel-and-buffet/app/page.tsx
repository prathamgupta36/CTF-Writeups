import { LoginForm } from "@/components/LoginForm";
import { SecretAreaButton } from "@/components/SecretAreaButton";

export default function Home() {
  return (
    <main>
      <div style={{ textAlign: "center", marginBottom: "50px" }}>
        <h1
          style={{
            fontSize: "2.5rem",
            fontWeight: 700,
            marginBottom: "10px",
            background: "linear-gradient(90deg, #00d4ff, #7b2cbf)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            backgroundClip: "text",
          }}
        >
          Parallel and Buffet
        </h1>
        <p style={{ color: "#a1a1aa", fontSize: "1.1rem" }}>
          A secure secret management system
        </p>
      </div>

      <div
        style={{
          background: "rgba(255, 255, 255, 0.05)",
          backdropFilter: "blur(10px)",
          borderRadius: "16px",
          padding: "30px",
          border: "1px solid rgba(255, 255, 255, 0.1)",
          marginBottom: "24px",
        }}
      >
        <h2 style={{ fontSize: "1.3rem", marginTop: 0, marginBottom: "20px", color: "#f4f4f5" }}>
          Login
        </h2>
        <LoginForm />
      </div>

      <div
        style={{
          background: "rgba(255, 255, 255, 0.05)",
          backdropFilter: "blur(10px)",
          borderRadius: "16px",
          padding: "30px",
          border: "1px solid rgba(255, 255, 255, 0.1)",
          marginBottom: "24px",
        }}
      >
        <h2 style={{ fontSize: "1.3rem", marginTop: 0, marginBottom: "20px", color: "#f4f4f5" }}>
          Secret Area
        </h2>
        <p style={{ color: "#a1a1aa", marginBottom: "24px", lineHeight: 1.6 }}>
          Access your protected secrets. Authentication is required to view the content.
        </p>
        <SecretAreaButton />
      </div>

      <div
        style={{
          background: "rgba(251, 191, 36, 0.1)",
          borderRadius: "12px",
          padding: "20px 24px",
          border: "1px solid rgba(251, 191, 36, 0.3)",
        }}
      >
        <h3 style={{ fontSize: "1rem", marginTop: 0, marginBottom: "10px", color: "#fbbf24" }}>
          Notice
        </h3>
        <p style={{ color: "#d4d4d8", margin: 0, fontSize: "0.9rem", lineHeight: 1.6 }}>
          The secret area is protected by strong authentication. Only authorized users can access it.
        </p>
      </div>
    </main>
  );
}
