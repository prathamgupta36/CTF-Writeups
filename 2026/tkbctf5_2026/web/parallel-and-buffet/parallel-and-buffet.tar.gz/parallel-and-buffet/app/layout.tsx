import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Parallel and Buffet",
  description: "A secure secret management system",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        style={{
          fontFamily:
            '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
          margin: 0,
          padding: 0,
          minHeight: "100vh",
          background: "linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)",
          color: "#e4e4e7",
        }}
      >
        <div style={{ maxWidth: "900px", margin: "0 auto", padding: "40px 20px" }}>
          {children}
        </div>
      </body>
    </html>
  );
}
