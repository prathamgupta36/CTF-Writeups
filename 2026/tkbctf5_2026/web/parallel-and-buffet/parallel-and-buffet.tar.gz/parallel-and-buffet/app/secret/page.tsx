import { SecretContent } from "@/components/SecretContent";

export default async function SecretPage() {
  return (
    <div>
      <h3 style={{ fontSize: "1.1rem", marginTop: 0, marginBottom: "12px", color: "#f4f4f5" }}>
        Welcome to the Secret Area
      </h3>
      <p style={{ color: "#a1a1aa", marginBottom: "24px", lineHeight: 1.6 }}>
        You have successfully authenticated. Click the button below to retrieve your secret message.
      </p>
      <SecretContent />
    </div>
  );
}
