import { redirect } from "next/navigation";
import { isAuthenticated } from "@/lib/auth";

export default async function SecretLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const authenticated = await isAuthenticated();

  if (!authenticated) {
    redirect("/");
  }

  return (
    <div
      style={{
        background: "rgba(34, 197, 94, 0.1)",
        borderRadius: "16px",
        padding: "30px",
        border: "1px solid rgba(34, 197, 94, 0.3)",
      }}
    >
      <div
        style={{
          marginBottom: "24px",
          paddingBottom: "20px",
          borderBottom: "1px solid rgba(34, 197, 94, 0.2)",
        }}
      >
        <h2 style={{ margin: 0, fontSize: "1.3rem", color: "#4ade80" }}>
          Authenticated Area
        </h2>
      </div>
      {children}
    </div>
  );
}
