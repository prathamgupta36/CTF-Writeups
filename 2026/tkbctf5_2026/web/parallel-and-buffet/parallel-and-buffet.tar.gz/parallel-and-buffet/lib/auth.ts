import { cookies } from "next/headers";
import { randomBytes } from "node:crypto";

const ADMIN_SECRET = process.env.ADMIN_SECRET || randomBytes(32).toString("hex");

export async function isAuthenticated(): Promise<boolean> {
  const cookieStore = await cookies();
  const authToken = cookieStore.get("auth_token");
  
  if (!authToken) {
    return false;
  }
  
  return authToken.value === ADMIN_SECRET;
}
