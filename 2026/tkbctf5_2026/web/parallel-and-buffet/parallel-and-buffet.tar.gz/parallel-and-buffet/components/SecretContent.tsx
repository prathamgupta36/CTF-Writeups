"use client";

import { useState } from "react";
import { getData } from "@/actions/data";

export function SecretContent() {
  const [message, setMessage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleClick = async () => {
    setLoading(true);
    try {
      const result = await getData("welcome");
      setMessage(result);
    } catch {
      setMessage("Error fetching data");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <button
        type="button"
        onClick={handleClick}
        disabled={loading}
        style={{
          padding: "12px 24px",
          background: loading
            ? "rgba(255, 255, 255, 0.1)"
            : "linear-gradient(90deg, #22c55e, #16a34a)",
          color: loading ? "#71717a" : "white",
          border: "none",
          borderRadius: "8px",
          cursor: loading ? "not-allowed" : "pointer",
          fontSize: "0.95rem",
          fontWeight: 600,
          transition: "all 0.2s",
        }}
      >
        {loading ? "Loading..." : "Show Message"}
      </button>

      {message && (
        <div
          style={{
            marginTop: "24px",
            padding: "20px",
            background: "rgba(0, 0, 0, 0.4)",
            borderRadius: "12px",
            border: "1px solid rgba(0, 212, 255, 0.3)",
          }}
        >
          <code
            style={{
              color: "#00ff88",
              fontFamily: '"Fira Code", "SF Mono", Monaco, monospace',
              fontSize: "1rem",
              lineHeight: 1.6,
            }}
          >
            {message}
          </code>
        </div>
      )}
    </div>
  );
}
