"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { login } from "@/actions/auth";

export function LoginForm() {
  const router = useRouter();
  const [token, setToken] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const success = await login(token);
    if (success) {
      alert("Login successful!");
      router.refresh();
    } else {
      alert("Login failed. Invalid token.");
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div style={{ marginBottom: "20px" }}>
        <label
          htmlFor="token"
          style={{
            display: "block",
            marginBottom: "8px",
            color: "#d4d4d8",
            fontSize: "0.9rem",
            fontWeight: 500,
          }}
        >
          Auth Token
        </label>
        <input
          type="password"
          id="token"
          name="token"
          placeholder="Enter your auth token"
          value={token}
          onChange={(e) => setToken(e.target.value)}
          style={{
            width: "100%",
            padding: "12px 16px",
            background: "rgba(0, 0, 0, 0.3)",
            border: "1px solid rgba(255, 255, 255, 0.2)",
            borderRadius: "8px",
            color: "#f4f4f5",
            fontSize: "1rem",
            outline: "none",
            boxSizing: "border-box",
          }}
        />
      </div>
      <button
        type="submit"
        style={{
          width: "100%",
          padding: "12px 24px",
          background: "linear-gradient(90deg, #7b2cbf, #00d4ff)",
          color: "white",
          border: "none",
          borderRadius: "8px",
          fontSize: "1rem",
          fontWeight: 600,
          cursor: "pointer",
        }}
      >
        Login
      </button>
    </form>
  );
}
