"use client";

import { useRouter } from "next/navigation";
import { checkAuth } from "@/actions/auth";

export function SecretAreaButton() {
  const router = useRouter();

  const handleClick = async () => {
    const authenticated = await checkAuth();
    if (authenticated) {
      router.push("/secret");
    } else {
      alert("You are not authenticated. Please login first.");
    }
  };

  return (
    <button
      onClick={handleClick}
      style={{
        display: "inline-block",
        padding: "12px 28px",
        background: "linear-gradient(90deg, #7b2cbf, #00d4ff)",
        color: "white",
        textDecoration: "none",
        borderRadius: "8px",
        fontWeight: 600,
        fontSize: "0.95rem",
        border: "none",
        cursor: "pointer",
      }}
    >
      Enter Secret Area
    </button>
  );
}
