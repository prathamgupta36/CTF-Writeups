"use server";

import { cookies } from "next/headers";
import { isAuthenticated } from "@/lib/auth";

export async function checkAuth(): Promise<boolean> {
  return await isAuthenticated();
}

export async function login(token: string): Promise<boolean> {
  if (token) {
    const cookieStore = await cookies();
    cookieStore.set("auth_token", token, {
      httpOnly: true,
      sameSite: "strict",
      path: "/",
    });
  }

  return await isAuthenticated();
}
