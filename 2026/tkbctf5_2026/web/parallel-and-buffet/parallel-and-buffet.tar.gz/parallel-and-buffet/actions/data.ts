"use server";

import { readFileSync } from "node:fs";

const DATA_STORE: Record<string, string> = {
  welcome: "Welcome to the secret area!",
  hint: "There might be something hidden here...",
  secret: "The real secret is not here.",
};

export async function getData(key: string): Promise<string> {
  if (key === "flag") {
    try {
      return readFileSync("/flag.txt", "utf-8").trim();
    } catch {
      return "tkbctf{dummy}";
    }
  }

  return DATA_STORE[key] || "Unknown key";
}
