import java.io.InputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

import jdk.internal.org.objectweb.asm.ClassReader;
import jdk.internal.org.objectweb.asm.ClassVisitor;
import jdk.internal.org.objectweb.asm.Handle;
import jdk.internal.org.objectweb.asm.MethodVisitor;
import jdk.internal.org.objectweb.asm.Opcodes;

public class Server {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String line = br.readLine();
        byte[] classBytes;
        try {
            classBytes = Base64.getDecoder().decode(line);
        } catch (Exception e) {
            System.out.println("invalid base64");
            return;
        }
        if (classBytes.length > 650) {
            System.out.println("class too large");
            return;
        }
        if (new String(classBytes, StandardCharsets.US_ASCII).contains("Runtime")) {
            System.out.println("Runtime string detected");
            return;
        }
        if (hasInvoke(classBytes)) {
            System.out.println("invoke* instruction detected");
            return;
        }
        Class<?> cls = new ByteClassLoader().define(classBytes);
        cls.getMethod("run").invoke(null);
    }

    private static class ByteClassLoader extends ClassLoader {
        public Class<?> define(byte[] bytes) {
            return defineClass(null, bytes, 0, bytes.length);
        }
    }

    private static boolean hasInvoke(byte[] classBytes) throws Exception {
        ClassReader reader = new ClassReader(classBytes);
        InvokeScanVisitor visitor = new InvokeScanVisitor();
        reader.accept(visitor, ClassReader.SKIP_DEBUG | ClassReader.SKIP_FRAMES);
        return visitor.hasInvoke;
    }

    private static class InvokeScanVisitor extends ClassVisitor {
        boolean hasInvoke = false;

        InvokeScanVisitor() {
            super(Opcodes.ASM9);
        }

        @Override
        public MethodVisitor visitMethod(int access, String name, String desc, String sig, String[] exceptions) {
            return new MethodVisitor(Opcodes.ASM9) {
                @Override
                public void visitMethodInsn(int opcode, String owner, String name, String descriptor, boolean isInterface) {
                    hasInvoke = true;
                }

                @Override
                public void visitInvokeDynamicInsn(String name, String descriptor, Handle bsmHandle, Object... bsmArgs) {
                    hasInvoke = true;
                }
            };
        }
    }
}
