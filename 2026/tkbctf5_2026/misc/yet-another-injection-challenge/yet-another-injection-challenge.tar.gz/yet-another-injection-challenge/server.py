import subprocess

while expr := input("expr: ").strip():
    if any(bloked in expr for bloked in ["\"", ".", "env", "load", "file"]):
        print("blocked")
        continue
    try:
        subprocess.run(["yq", "-n", expr], capture_output=True, timeout=2, check=True)
        print("ok")
    except:
        print("error")
