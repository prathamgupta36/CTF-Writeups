import random
import os
from Crypto.Util.Padding import pad
from Crypto.Cipher import AES

flag = os.environ.get("FLAG", "tkbctf{dummy}")
a = b = 1
for _ in range(100):
    print(random.getrandbits(b))
    a, b = b, a + b
print(AES.new(random.randbytes(16), AES.MODE_ECB).encrypt(pad(flag.encode(), 16)).hex())
