import os
from math import gcd
from Crypto.Util.number import getPrime, bytes_to_long

e = 11
flag = os.environ.get("FLAG", f"tkbctf{{{"dummy"*12}}}")
flag = flag.removeprefix("tkbctf{").removesuffix("}").encode()
assert len(flag) == 60
m = bytes_to_long(flag)
p = getPrime(512)
q = getPrime(512)
assert gcd((p - 1) * (q - 1), e) == 1
n = p * q
c = pow(m, e, n)
hint1 = n % m
hint2 = n % (m + e)

print(f"{n=}")
print(f"{e=}")
print(f"{c=}")
print(f"{hint1=}")
print(f"{hint2=}")
